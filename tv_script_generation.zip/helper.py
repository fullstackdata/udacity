import os
import pickle


def load_data(path):
    """
    Load Dataset from File
    """
    input_file = os.path.join(path)
    with open(input_file, "r") as f:
        data = f.read()

    return data


def preprocess_and_save_data(dataset_path, token_lookup, create_lookup_tables):
    """
    Preprocess Text Data
    """
    text = load_data(dataset_path)

    # Ignore notice, since we don't use it for analysing the data
    text = text[81:]

    token_dict = token_lookup()
    for key, token in token_dict.items():
        text = text.replace(key, ' {} '.format(token))

    text = text.lower()
    text = text.split()

    vocab_to_int, int_to_vocab = create_lookup_tables(text)
    int_text = [vocab_to_int[word] for word in text]
    pickle.dump((int_text, vocab_to_int, int_to_vocab, token_dict), open('preprocess.p', 'wb'))


def load_preprocess():
    """
    Load the Preprocessed Training data and return them in batches of <batch_size> or less
    """
    return pickle.load(open('preprocess.p', mode='rb'))


def save_params(params):
    """
    Save parameters to file
    """
    pickle.dump(params, open('params.p', 'wb'))


def load_params():
    """
    Load parameters from file
    """
    return pickle.load(open('params.p', mode='rb'))

def create_lookup_tables(text):
    """
    Create lookup tables for vocabulary
    :param text: The text of tv scripts split into words
    :return: A tuple of dicts (vocab_to_int, int_to_vocab)
    """
    # TODO: Implement Function
    lower_text=map(lambda x:x.lower(), text)
    txt_set=set(lower_text)
    ids=list(range(0,len(txt_set)))
    vocab_to_int=dict(zip(txt_set, ids))
    int_to_vocab=dict(zip(ids, txt_set))
    tpl=(vocab_to_int, int_to_vocab)
    return tpl

def token_lookup():
    """
    Generate a dict to turn punctuation into a token.
    :return: Tokenize dictionary where the key is the punctuation and the value is the token
    """
    # TODO: Implement Function
    token_dict = {".":"||Period||",
                ",":"||comma||",
                '''"''':"||Quotation_Mark||",
                ";":"||Semicolon||",
                "!":"||Exclamation_Mark||",
                "?":"||Question_Mark||",
                "(":"||Left_Parentheses||",
                ")":"||Right_Parentheses||",
                "--":"||Dash||",
                "\n":"||Return||"}
    return token_dict


# preprocess_and_save_data('./data/simpsons/moes_tavern_lines.txt',token_lookup,create_lookup_tables)
